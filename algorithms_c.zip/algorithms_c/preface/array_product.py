'''
Implementation from "Algorithms with Implementations in C: A quantitative Approach"
void array_multiply(int a[], int b[], int n)
{
    int sub = 1;
    for (int i = 1; i < n; i++) {
        sub *= a[i - 1];
        b[i] = sub;
    }

    b[0] = 1;
    sub = 1;
    for (int i = n - 1; i > 0; i--) {
        sub *= a[i];
        b[i - 1] *= sub;
    }
}
'''
import time
def products(a):
    n = len(a)
    b = [0] * n

    b[0] = 1
    
    sub = 1
    for i in range(1, n):
        sub = sub * a[i - 1]
        b[i] = sub
        
    sub = 1
    for i in range (n - 1, 0, -1):
        sub = sub * a[i]
        b[i - 1] = sub * b[i -1]
        
    return b

#driver
a = [1, 2, 3, 4, 5, 6, 7, 8, 9]

start = time.time()
N = 10000000
for i in range(N):
    b = products(a)
    
print("duration =", str(int(time.time()-start)), "seconds")

print(b)
