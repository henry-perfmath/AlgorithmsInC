#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

int get_milliseconds()
{
	return clock() * 1000 / CLOCKS_PER_SEC;
}

int cmp_func(const void *a, const void *b)
{
	return (*(int *) a - *(int *) b);
}

bool linear_search(const int n, const int a[], const int k, int *i, int *j)
{
	int start = 0, end = n - 1;
	bool found_it = false;

	while (start < end)
	{
		int sum = a[start] + a[end];
		if (sum < k)
		{
			start++;
		}
		else if (sum > k)
		{
			end--;
		}
		else
		{
			found_it = true;
			*i = start;
			*j = end;
			break;
		}
	}
	return found_it;
}

int main()
{
	int n = 10;
	int k = 5;
	printf("enter n and k (10 5): ");
	scanf("%d %d", &n, &k);

	srand(time(NULL));

	int a[n];
	clock_t t0 = get_milliseconds();
	for (int i = 0; i < n; i++)
		a[i] = n / 2 - rand() % n;

	clock_t t1 = get_milliseconds();
	qsort(a, n, sizeof(int), cmp_func);

	for (int i = 0; i < n; i++)
		(i < (n - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);

	clock_t t2 = get_milliseconds();
	int i = 0, j = 0;
	bool found_it = linear_search(n, a, k, &i, &j);
	if (found_it)
		printf("found it: start = %d end = %d\n", i, j);
	else
		printf(" doesn't exist\n");

	clock_t t3 = get_milliseconds();
	printf("search time: %d ms\n", (int) (t3 - t2));
}
