#include <stdio.h>
#include <string.h>

char *search_substring(char *sub, char *str)
{
	char *main_str, *sub_str, *sub_ptr;

	// move char by char sequentially
	for (int ch = 0; str[ch]; ch++)
	{
		main_str = &str[ch]; // main_str gets the address
		sub_ptr = main_str; // set sub_ptr to main_str for returning the substring found
		sub_str = sub; 		  // sub_str points to the input sub string

		// check if sub string found
		while (*sub_str && *sub_str == *main_str)
		{
			main_str++;
			sub_str++;
		}

		// if sub_str is found, return sub_str
		if (!*sub_str)
			return sub_ptr;
	}
	return " not found\n";
}

char *check_substring(char *sub, char *str)
{
	char *main_str, *sub_str, *sub_ptr;
	main_str = str;
	sub_ptr = main_str;
	sub_str = sub;

	while (*main_str != '\0')
	{ // do not use while (main_str)
		if (*main_str == *sub_str)
		{
			sub_str++;
			main_str++;
			if (*sub_str == '\0')
				return sub_ptr;
		}
		else if (*main_str == sub[0])
		{
			sub_ptr = main_str;
			sub_str = sub;
			sub_str++;
			main_str++;
		}
		else
		{
			main_str++;
			sub_ptr = main_str;
			sub_str = sub;
		}
	}
	return " not found\n";
}

int main()
{
	//option 1
	//char *str = "This is a test";
	//char *sub_str = "is";

	//option 2
	//char str[] = "This is a test";
	//char *sub_str = "is";

	// option 3
	char str[30];
	char sub_str[30];
	strcpy(str, "This is a test");

	char sub_string_found[30];
	do
	{
		printf("enter a substring or return to exit:");
		//scanf("%s", sub_str); // does not read whitespaces
		gets(sub_str);
		printf("You entered %s with length = %ld\n", sub_str, strlen(sub_str));
		/*
		 * char sub_string_found[]; needs a size
		 * char sub_string_found[30]; not assignable. must use strcpy
		 */
		strcpy(sub_string_found, search_substring(sub_str, str));
		//strcpy(sub_string_found, check_substring (sub_str, str));
		printf("search substring \"%s\": %s\n", sub_str, sub_string_found);
	} while (strlen(sub_str) > 0);
}

