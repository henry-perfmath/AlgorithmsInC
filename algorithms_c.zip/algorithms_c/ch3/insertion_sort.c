/*
 * insertion_sort.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: henry
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int MAX_ARRAY_SIZE = 10;

void insertion_sort1(int a[], int n)
{
	for (int i = 1; i < n; ++i)
	{
		int j = i;
		while (j > 0 && a[j - 1] > a[j])
		{
			int tmp = a[j];
			a[j] = a[j - 1];
			a[j - 1] = tmp;

			--j;
		}
	}
}

// faster by moving a[i] to its position in one go
void insertion_sort2(int a[], int n)
{
	for (int i = 1; i < n; ++i)
	{
		int j = i;

		int curr_item = a[j];
		while (j >= 0 && a[j - 1] > curr_item)
		{
			a[j] = a[j - 1];
			--j;
		}

		a[j] = curr_item;
	}
}

int main()
{
	srand(time(0));

	printf("before sorting:\n");
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++)
	{
		a[i] = rand() % 30;
		(i < (MAX_ARRAY_SIZE - 1)) ?
				printf("%d ", a[i]) : printf("%d \n", a[i]);
	}

	insertion_sort2(a, MAX_ARRAY_SIZE);

	printf("after sorting:\n");
	for (int i = 0; i < MAX_ARRAY_SIZE; i++)
	{
		(i < (MAX_ARRAY_SIZE - 1)) ?
				printf("%d ", a[i]) : printf("%d \n", a[i]);
	}
}
