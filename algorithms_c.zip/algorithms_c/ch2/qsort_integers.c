/*
 * qsort_integers.c
 *
 *  Created on: Jan 1, 2019
 *      Author: henryliu
 */

#include <stdio.h>
#include <stdlib.h>

int cmp_function(const void *a, const void *b) {
	return (*(int *)a - *(int *)b);
}

int main() {
	int a[] = {1, 5, 9, 30, 20, 12, 20};
	int n = sizeof(a) / sizeof(a[0]);
	qsort((int *)a, n, sizeof(int), cmp_function);
	for (int i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	putchar('\n');
}
