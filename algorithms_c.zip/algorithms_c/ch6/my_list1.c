#include <stdio.h>
#include <stdlib.h>
#include "my_list1.h"

bool is_empty(const Node **head)
{
	return *head == NULL;
}

// check if memory is available for allocating a node pointer
bool is_full()
{
    Node *node_ptr;
    if (!(node_ptr = (Node *) malloc(sizeof(Node))))
    	return true;

    free(node_ptr);
    return false;
}

unsigned int length(const Node **head)
{
    const Node *cursor = *head;

    unsigned int count = 0;
    while (cursor != NULL)
    {
        ++count;
        cursor = cursor->next;
    }
    
    return count;
}

bool insert(Item item, Node **head)
{
	Node *new_node = (Node *) malloc(sizeof(Node));
    
    if (!new_node)
        return false;
    else
    {
    	new_node->item = item;
    	new_node->next = NULL;
    }

    // do not create a variable until needed
	Node *cursor = *head;
    if (cursor == NULL)
        *head = new_node;
    else
    {
        while (cursor->next)
        	cursor = cursor->next;

        cursor->next = new_node;
    }
    
    return true;
}

void traverse(const Node **head, void (*func_ptr)(Item item))
{
    const Node *cursor = *head;
    
    while (cursor != NULL)
    {
        (*func_ptr)(cursor->item);
        cursor = cursor->next;
    }
}

void clear(Node **head)
{
	Node *node = *head;
	while (node) {
		Node *ptr_save = node->next;
		free(node);
		node = ptr_save;
	}
}

void clear_circular(Node **head, int length)
{
    Node *ptr_save;
    int count = 0;
    while (count < length && *head != NULL)
    {
        ptr_save = (*head)->next;
        free(*head);
        *head = ptr_save;
        count++;
    }
}

