#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "my_list2.h"

void display(Item item)
{
	printf("%d ", item.data);
}

void check_empty(Node *list)
{
	if (is_empty(list))
		printf("Empty list\n");
	else
	{
		printf("Contents of the data list: ");
		traverse(list, display);
		printf("\n");
	}
}

void fold(int position, Node *list)
{
	printf("calling fold at position = %d ", position);
	Node* curr = list;
	Node* fold_ptr;
	int count = 1;
	while (curr->next != NULL)
	{
		if (count == position)
		{
			fold_ptr = curr;
			printf("folding at %d \n", curr->item.data);
		}
		else
			printf("skip folding at %d for %d \n", count, curr->item.data);

		curr = curr->next;
		count++;
	}

	printf("assigning folding fold_ptr at %d ", curr->item.data);
	curr->next = fold_ptr;
}

void check_circular_linked_list(Node *list)
{
	// seg 0: declare fast and slow pointers
	Node *fast = list;
	Node *slow = list;

	// seg 1: move both pointers. Break if they meet
	printf("find meeting point ...\n");
	while (fast != NULL && fast->next != NULL)
	{
		slow = slow->next;
		fast = fast->next;
		fast = fast->next;
		if (slow == fast)
			break;
	}

	// seg 2: no loop if fast or fast->next NULL
	if (fast == NULL || fast->next == NULL)
		return;
	printf("circular linked list meeting point: %d\n", slow->item.data);

	// seg 3: find entry point for circular linked list
	printf("\nfind entry point for circular linked list...\n");
	slow = list;
	while (slow != fast)
	{
		slow = slow->next;
		fast = fast->next;
	}
	printf("circular linked list entry point: %d\n", fast->item.data);
}

int main()
{
	// create an empty mylist
	Node *list = NULL;

	if (is_full())
	{
		fprintf(stderr, "No memory available! Bye!\n");
		exit(1);
	}

	int SIZE = 19;
	for (int i = 0; i < SIZE; i++)
	{
		Item temp;
		temp.data = i + 1;
		printf("insert %d\n", temp.data);
		list = insert(temp, list);
	}

	traverse(list, display);
	fold(12, list);

	printf("calling checkCircularLinkedList:\n");
	check_circular_linked_list(list);
	list = clear_circular(list, SIZE);
	check_empty(list);
	return 0;
}
