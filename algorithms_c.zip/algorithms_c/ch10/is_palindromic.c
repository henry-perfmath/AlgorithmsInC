#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// can do so much with for. No need to have two separate loops
bool is_palindromic0(const char* str) {
	for (int i = 0, j = strlen(str) - 1; i < j; ++i, --j) {
		if (str[i] != str[j])
			return false;
	}
	return true;
}

bool is_palindromic(const char* str) {
	int n = strlen(str);
	for (int i = 0; i< n - 1; i++) {
		if (str[i] != str[n - 1 - i])
			return false;
	}
	return true;
}


int main() {
	char* str = "12321";
	is_palindromic(str) ? printf("%s is palindromic\n", str) : printf("%s is not palindromic\n", str);
	str = "Madam, I'm Adam";
	is_palindromic(str) ? printf("%s is palindromic\n", str) : printf("%s is not palindromic\n", str);
}
