#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool check_array_sorted(int a[], int start, int end) {
	if (start < end) {
		printf("start = %d, end = %d, a[start] = %d, a[end]= %d\n", start, end, a[start], a[end]);
		if (a[start] <= a [start + 1]) {
			 return check_array_sorted(a, start + 1, end); // msu have return here
		} else {
			return false;
		}
	}
	return true;
}

// asumeing ascending order
bool check_array_sorted2(int a[], int start, int end) {
	for (int i = start; i < end; i++) {
		if (a[i] > a [i + 1]) return false;
	}
	return true;
}

int main() {

	int a[] = {1, 8, 9, 10, 12, 15, 20, 25, 26, 36, 35};
	int n = sizeof(a) / sizeof(a[0]);
	if (check_array_sorted(a, 0, n - 1)) {
		printf("array sorted\n");
	} else {
		printf("array not sorted\n");
	}

	if (check_array_sorted2(a, 0, n - 1)) {
		printf("array sorted\n");
	} else {
		printf("array not sorted\n");
	}
}
