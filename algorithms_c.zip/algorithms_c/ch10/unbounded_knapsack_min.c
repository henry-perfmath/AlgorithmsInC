#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int max(int a, int b) { return (a > b) ? a : b; }
int min(int a, int b) { return (a < b) ? a : b; }

int unbounded_knapsack(int max_weight, int n, int v[], int w[])
{
    // min_value[weight]: max total value for weight from 0 to max_weight
    int weight, min_value[max_weight + 1];
    for (weight = 0; weight <= max_weight; weight++) {
    	min_value[weight] = 0;
    }

    for (weight = 1; weight <= max_weight; weight++)
      for (int j = 0; j < n; j++)
         if (w[j] <= weight) {
            min_value[weight] = max(min_value[weight], v[j] + min_value[weight - w[j]]);
            printf("weight = %d, j = %d, min_value[%d]= %d, w[%d]=%d, min_value[%d]=%d, v[%d] = %d\n",
            		weight, j, weight, min_value[weight], j, w[j], weight - w[j], min_value[weight - w[j]], j, v[j]);
         }
    for (weight = 1; weight <= max_weight; weight++)
    	printf("min_value[%d]= %d\n", weight, min_value[weight]);
    return min_value[max_weight];
}

void test1() {
    int max_weight = 12;
    int v[] = {1, 2, 3};
    int w[] = {9, 4, 1};
    int n = sizeof(v)/sizeof(v[0]);

    printf("test1: %d\n\n", unbounded_knapsack(max_weight, n, v, w));
}
void test2() {
    int max_weight = 12;
    int v[] = {1, 1, 1};
    int w[] = {9, 4, 1};
    int n = sizeof(v)/sizeof(v[0]);

    printf("test2: %d\n\n", unbounded_knapsack(max_weight, n, v, w));
}

void test3() {
    int max_weight = 8;
    int v[] = {1, 4, 5, 7};
    int w[] = {1, 3, 4, 5};
    int n = sizeof(v)/sizeof(v[0]);

    printf("test3: %d\n\n", unbounded_knapsack(max_weight, n, v, w));
}
int main()
{
    //test1();
    test2();
    //test3();
    return 0;
}
