#include<stdio.h>

int max(int a, int b) { return (a > b) ? a : b; }

int knapsack(int W, int w[], int v[], int n)
{
   if (n == 0 || W == 0)
       return 0;

   if (w[n - 1] > W)
       return knapsack(W, w, v, n - 1);

   else {
	   return max(knapsack(W, w, v, n - 1),
			      knapsack(W - w[n - 1], w, v, n - 1) + v[n - 1]);
   }
}

int knapsack_dp(int W, int w[], int v[], int n)
{
   int mv[n + 1][W + 1];

   for (int i = 0; i <=n; i++)
	   for (int ww = 0; ww <= W; ww++)
		   mv[i][ww] = 0;

   for (int i = 1; i <= n; i++) {
       for (int ww = 1; ww <= W; ww++){
    	   mv[i][ww]  = mv[i - 1][ww];

    	   int weight_off = ww - w[i - 1];
    	   if (weight_off >= 0) {
        	   mv[i][ww] = max(mv[i][ww],  v[i - 1] + mv[i - 1][weight_off]);
           }
       }
   }

   return mv[n][W];
}

void test1() {
    int w[] = {1, 4, 9};
    int v[] = {1, 1, 1};

    int W = 12;
    int n = sizeof(v)/sizeof(v[0]);
    printf("test1 (recur): %d\n", knapsack_recur(W, w, v, n));
    printf("test1 (dp): %d\n", knapsack_dp(W, w, v, n));
}

void test2() {
    int w[] = {12, 2, 1, 4, 1};
    int v[] = {4, 2, 1, 10, 2};

    int W = 9;
    int n = sizeof(v)/sizeof(v[0]);
    printf("test2 (recur): %d\n", knapsack_recur(W, w, v, n));
    printf("test2 (dp): %d\n", knapsack_dp(W, w, v, n));
}

int main()
{
    test1();
    test2();
    return 0;
}
