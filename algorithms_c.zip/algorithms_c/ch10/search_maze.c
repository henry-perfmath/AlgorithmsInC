#include <stdio.h>
#include <stdbool.h>

#define N 4

bool search(int maze[N][N], int x, int y, int sol[N][N]);

void print_solution(int sol[N][N])
{
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
			printf(" %d ", sol[i][j]);
		printf("\n");
	}
}

bool is_valid(int maze[N][N], int x, int y)
{
	if(x >= 0 && x < N && y >= 0 && y < N && maze[x][y] == 1)
		return true;

	return false;
}

// (x0, y0) are start point
bool solver(int maze[N][N], int x0, int y0)
{
	int sol[N][N] = { {0, 0, 0, 0},
		{0, 0, 0, 0},
		{0, 0, 0, 0},
		{0, 0, 0, 0}
	};

	if(search(maze, x0, y0, sol) == false)
	{
		printf("Solution doesn't exist for (%d, %d)\n", x0, y0);
		return false;
	}

	printf("Solution for (%d, %d):\n", x0, y0);
	print_solution(sol);
	return true;
}

// (x, y): next move or destintaion
bool search(int maze[N][N], int x, int y, int sol[N][N])
{
	// done and return true
	if(x == N-1 && y == N-1)
	{
		sol[x][y] = 1;
		return true;
	}

	// Check if (x, y) within the maze
	if(is_valid(maze, x, y))
	{
		// pre-mark (x,y) good
		sol[x][y] = 1;

		/* try one step forward in x direction */
		if (search(maze, x + 1, y, sol) == true)
			return true;

		/* try one step down in y direction */
		if (search(maze, x, y + 1, sol) == true)
			return true;

		// mices failed so backtrack with unmark
		sol[x][y] = 0;
		return false;
	}
	// (x, y): next move or destintaion
	return false;
}

int main()
{
	int maze[N][N] = { {1, 0, 0, 0},
					   {1, 1, 0, 1},
					   {0, 1, 0, 0},
					   {1, 1, 1, 1} };

	solver(maze, 0, 0);
	solver(maze, 0, 1);
	solver(maze, 1, 0);
	return 0;
}

