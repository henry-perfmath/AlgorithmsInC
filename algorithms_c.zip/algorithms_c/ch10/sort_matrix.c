#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void max_heapify(int *a, int heap_size, int index) {
	int left = 2 * index + 1;
	int right = 2 * index + 2;
	int largest = 0;

	if (left < heap_size && a[left] > a[index])
		largest = left;
	else
		largest = index;

	if (right < heap_size && a[right] > a[largest])
		largest = right;

	if (largest != index)
	{
		int temp = a[index];
		a[index] = a[largest];
		a[largest] = temp;

		max_heapify(a, heap_size, largest);
	}
}

void heap_sort(int *a, int count) {
	int heap_size = count;

	for (int p = (heap_size - 1) / 2; p >= 0; --p)
		max_heapify(a, heap_size, p);

	for (int i = count - 1; i > 0; --i)
	{
		int temp = a[i];
		a[i] = a[0];
		a[0] = temp;

		--heap_size;
		max_heapify(a, heap_size, 0);
	}
}

int main() {
	int dim = 9;
	int matrix[dim][dim];
	int n = 9 * 9;
	int a[n];
	srand(time(0));
	for (int i = 0; i < n; i++) {
		a[i] = rand() % (2 * n);
		int row_num = i / dim;
		int col_num = i % dim;
		matrix[row_num][col_num] = a[i];
		printf("i = %d, row = %d, col = %d, element = %d\n", i, row_num, col_num, a[i]);
	}

	heap_sort((int *)matrix, n); //heapify an array initialized at the start

	for (int i = 0; i < dim; i++)
		for (int j = 0; j < dim; j++) {
			int val = matrix[i][j];
			printf("%d ", val);
			if (j == (dim - 1)) putchar('\n');
		}
}
