#include <stdio.h>
#define N 4

void print_spiral (int offset, int n, int a[n][n]) {
	printf("offset = %d, n = %d\n", offset, n);
	if (n % 2 == 0 && offset >= n / 2) return;
	if (n % 2 == 1 && offset > n / 2) return;

	int i, j;
	// print upper
	for (j = offset; j < n - offset; j++) {
		printf("%d ", a[offset][j]);
	}

	// right side
	for (i = offset + 1; i < n - offset; i++) {
		printf("%d ", a[i][n - offset - 1]);
	}

	//bottom
	for (j = n - 2 - offset; j >=offset; j--) {
		printf("%d ", a[n - 1 - offset][j]);
	}

	// left
	for (i = n - 2 - offset; i > offset; i--) {
		printf("%d ", a[i][offset]);
	}
	putchar('\n');
	offset++;
	print_spiral(offset, n, a);
}
void test1() {
	int n = 3;
	int a[3][3] = {{1, 2, 3}, {4, 5, 6}, {7,8, 9}};
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			printf("%d ", a[i][j]);
	putchar('\n');
	print_spiral(0, n, a);
}
void test2() {
	int n = N;
	int a[N][N] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			printf("%d ", a[i][j]);
	putchar('\n');
	print_spiral(0, N, a);
}

int main() {
	test1();
	test2();
}
