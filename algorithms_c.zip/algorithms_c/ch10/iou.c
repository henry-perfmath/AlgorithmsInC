#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

typedef struct rect {int x, y, width, height;} Rect;

float compute_iou (Rect r1, Rect r2) {
	printf("%d %d %d %d\n", r1.x, r1.width, r2.x, r2.width);
	printf("%d %d %d %d\n", r1.y, r1.height, r2.y, r2.height);
	bool c1 = r1.x + r1.width > r2.x && r1.x < r2.x + r2.width;
	bool c2 = r1.y + r1.height > r2.y && r1.y < r2.y + r2.height;

	float iou = 0.0;
	if (c1 && c2) {
		printf("two rects intersect\n");
		int iou_num = (r1.x + r1.width - r2.x) * (r1.y + r1.height - r2.y);
		int iou_den = r1.width * r1.height + r2.width * r2.height - iou_num;
		printf("iou_num = %d, iou_den = %d\n", iou_num, iou_den);
		iou = (float) iou_num / iou_den;
	} else {
		printf("two rects do not intersect\n");
	}
	return iou;
}

int main() {
	Rect r1 = {0, 0, 3, 3};
	Rect r2 = {1, 1, 4, 4};
	float iou = compute_iou (r1, r2);
	printf("iou: %f\n", iou);
}
