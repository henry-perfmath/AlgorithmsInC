/*
 * atoi.c
 *
 *  Created on: Nov 30, 2018
 *      Author: henryliu
 */

#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int main() {
	char *a = "123";
	int length = strlen(a);

	int number = 0;

	int i = 0;
	while (i < length) {
		number = number * 10 + (a[i] - '0');
		i++;
	}
	printf("number = %d\n", number);
}
