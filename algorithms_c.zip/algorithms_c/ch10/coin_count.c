#include <stdio.h>

int count( int a[], int n, int V )
{
    if (V == 0) return 1;

    if (V < 0 || (n <= 0 && V >= 1)) return 0;

    return count(a, n - 1, V) + count(a, n, V - a[n - 1]);
}

int count_2d( int a[], int n, int V )
{
    int count[V + 1][n];

    for (int v = 0; v < V + 1; v++)
    	for (int i = 0; i < n; i++)
    		count[v][i] = (v == 0) ? 1 : 0;

    for (int v = 1; v < V + 1; v++) {
    	for (int i = 0; i < n; i++) {

        	if (v >= a[i]) count[v][i] = count[v - a[i]][i];
        	if (i >= 1) count[v][i] += count[v][i - 1];

        }
    }
    return count[V][n - 1];
}

int count_1d( int a[], int n, int V ){

    int count[V + 1];

    count[0] = 1;
    for (int v = 1; v <= V; v++)
    	count[v] = 0;

    for(int i = 0; i < n; i++)
        for(int v = a[i]; v <= V; v++)
            count[v] = count[v] + count[v - a[i]];

    return count[V];
}

void test1() {
    int a[] = {1, 5, 10};
    int n = sizeof(a)/sizeof(a[0]);
    int V = 13;
    printf("test1: count (recur): %d\n", count(a, n, V));
}

void test2() {
    int a[] = {1, 5, 10};
    int n = sizeof(a)/sizeof(a[0]);
    int V = 13;
    printf("test2: count_2: %d\n", count_2d(a, n, V));
}

void test3() {
    int a[] = {1, 5, 10};
    int n = sizeof(a)/sizeof(a[0]);
    int V = 13;
    printf("test3: count_1d: %d\n", count_1d(a, n, V));
}

int main() {
	test1();
	test2();
	test3();
}
