#include <stdio.h>
#include <stdlib.h>

int complete_cycle(int n, int a[])
{
	int index = 0; // index is like an offset
	int count = 0;
	while (count < n) {
		index += a[index]; // relative index to absolute index

		//printf("count = %d: index = %d, checking a[%d] = %d\n", count, index % n, index % n, a[index % n]);
		index = ((index %n) + n)% n; // modulo: c and java are different from python

		if (index == 0 && count < n - 1) // subcycle
			return 0;

		count++;
	}

	return index == 0; // complete or not
}

void test0() {
	int indices[] = {3, 2, 5, -3, 10, 7, 8};
	int n = sizeof(indices) / sizeof(indices[0]);

	if (complete_cycle(n, indices)) {
		printf("test 0: a complete cycle is found\n");
	} else {
		printf("test 0: no complete cycle found\n");
	}
}

void test1() {
	int indices[] = {3, 2, 5, -2, 10, 7, 8};
	int n = sizeof(indices) / sizeof(indices[0]);

	if (complete_cycle(n, indices)) {
		printf("test 1: a complete cycle is found\n");
	} else {
		printf("test 1: no complete cycle found\n");
	}
}

void test2() {
	int indices[] = {2, 2, -1};
	int n = sizeof(indices) / sizeof(indices[0]);

	if (complete_cycle(n, indices)) {
		printf("test 2: a complete cycle is found\n");
	} else {
		printf("test 2: no complete cycle found\n");
	}
}

void test3() {
	int indices[] = {2, 2, 0};
	int n = sizeof(indices) / sizeof(indices[0]);

	if (complete_cycle(n, indices)) {
		printf("test 3: a complete cycle is found\n");
	} else {
		printf("test 3: no complete cycle found\n");
	}
}

int main() {

	test0();
	test1();
	test2();
	test3();
}
