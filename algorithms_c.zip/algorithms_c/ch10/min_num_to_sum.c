#include <stdio.h>
#include <limits.h>

int min (int a, int b) {return (a < b) ? a : b;}

int min_items_recur(int a[], int n, int V)
{
   if (V == 0) return 0;

   int min_items = INT_MAX;

   for (int i = 0; i < n; i++)
	   if (a[i] <= V)
		   min_items = min(min_items, 1 + min_items_recur(a, n, V - a[i]));

   return min_items ;
}

int min_items_dp(int a[], int n, int V) {

    int min_items[V + 1];
    int included[V + 1];

    min_items[0] = 0;
    for (int v = 1; v <= V; v++)
    	min_items[v] = INT_MAX;

	for (int v = 1; v <= V; v++) {
		for (int i = 0; i < n; i++) {
			int sup_vi = v - a[i];
			if (sup_vi >= 0) {
				int sub_sol = 1 + min_items[sup_vi];
				if (sub_sol < min_items[v]) {
					min_items[v] = sub_sol;
					included[v] = a[i];
				}
			}
		}
	}

    printf("\nitems included for V = %d\n", V);
    int  v = V;
    while (v > 0) {
    	printf("included[%d] = %d ", v, included[v]);
        v = v - included[v];
    }
    putchar('\n');

    return min_items[V];
}

void test1() {
    int a[] =  {9, 4, 1};
    int n = sizeof(a)/sizeof(a[0]);
    int V = 12;
    printf("test1 (recur): %d\n", min_items_recur(a, n, V));
}

void test2() {
    int a[] =  {9, 4, 1};
    int n = sizeof(a)/sizeof(a[0]);
    int V = 12;
    printf("test2 (dp): %d\n", min_items_dp(a, n, V));
}

void test3() {
    int a[] =  {25, 16, 9, 4, 1};
    int n = sizeof(a)/sizeof(a[0]);
    int V = 30;
    printf("test3 (dp): %d\n", min_items_dp(a, n, V));
}

void test4() {
    int a[] =  {1, 5, 10, 25};
    int n = sizeof(a)/sizeof(a[0]);
    int V = 30;
    printf("test4 (dp): %d\n", min_items_dp(a, n, V));
}

int main()
{
	test1();
	test2();
	test3();
	test4();
}
