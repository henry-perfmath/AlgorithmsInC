#include <stdio.h>
#define N 3
#define M 4

void print_matrix_diagonal (int n, int m, int a[n][m])
{
	printf("\nn = %d, n = %d\n", n, m);
	int i = n - 1, j = 0;
	int level = 1;
	while (i >= 0 && j < m)
	{
		int k = j;
		while (k < level)
		{
			printf("%d ", a[i][k]);
			i++;
			k++;
		}
		putchar('\n');
		i = n - 1 - level;
		j = 0;
		level++;
	}

	i = 0, j = 1;
	while (i < n && j < m)
	{
		int k = j;
		while (k < m)
		{
			printf("%d ", a[i][k]);
			i++;
			k++;
		}
		putchar('\n');
		i = 0;
		j++;
	}
}

void test1() {
	int a[N][M] = {{1, 2, 3, 4},
				   {5, 6, 7, 8},
				   {9, 10, 11, 12}};

	print_matrix_diagonal(N, M, a);
}

void test2() {
	int a[N + 1][M + 1] = {{1, 2, 3, 4, 5},
				   	   	   {6, 7, 8, 9, 10},
						   {11, 12, 13, 14, 15},
						   {16, 17, 18, 19, 20}};

	print_matrix_diagonal(N + 1, M + 1, a);
}

int main() {
	test1();
	test2();
}
