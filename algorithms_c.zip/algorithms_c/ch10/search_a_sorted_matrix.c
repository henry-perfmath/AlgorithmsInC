#include<stdio.h>

int search(int n, int mat[n][n], int x)
{
   int i = 0, j = n - 1;  //set indexes for top right element. Do not immediately think using double-for loops
   while ( i < n && j >= 0 )
   {
       printf("try (i, j) at (%d, %d)\n", i, j);
      if ( mat[i][j] == x )
      {
         printf("\nFound at %d, %d\n", i, j);
         return 1;
      }
      if ( mat[i][j] > x )
        j--;
      else
        i++;
   }

   printf("\nElement not found");
   return 0;
}

int main()
{
  int mat[4][4] = { {10, 20, 30, 40},
                    {15, 25, 35, 45},
                    {27, 29, 37, 48},
                    {32, 33, 39, 50},
                  };
  search(4, mat, 29);
}

