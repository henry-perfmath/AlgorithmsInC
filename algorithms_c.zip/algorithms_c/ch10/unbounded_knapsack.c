#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int max(int a, int b) { return (a > b) ? a : b; }

int unbounded_knapsack(int W, int n, int v[], int w[])
{
    int mv[W + 1];
    for (int ww = 0; ww <= W; ww++) {
    	mv[ww] = 0;
    }

    for (int ww = 1; ww <= W; ww++)
      for (int i = 0; i < n; i++) {
    	  int weight_off = ww - w[i];
    	  if (weight_off >= 0) {
    		  mv[ww] = max(mv[ww], v[i] + mv[weight_off]);
         }
      }
    return mv[W];
}

void test1() {
    int max_weight = 12;
    int v[] = {1, 2, 3};
    int w[] = {9, 4, 1};
    int n = sizeof(v)/sizeof(v[0]);

    printf("test1: %d\n\n", unbounded_knapsack(max_weight, n, v, w));
}
void test2() {
    int max_weight = 12;
    int v[] = {1, 1, 1};
    int w[] = {9, 4, 1};
    int n = sizeof(v)/sizeof(v[0]);

    printf("test2: %d\n\n", unbounded_knapsack(max_weight, n, v, w));
}

void test3() {
    int max_weight = 8;
    int v[] = {1, 4, 5, 7};
    int w[] = {1, 3, 4, 5};
    int n = sizeof(v)/sizeof(v[0]);

    printf("test3: %d\n\n", unbounded_knapsack(max_weight, n, v, w));
}

void test4() {
    int max_weight = 100;
    int v[] = {10, 30, 20};
    int w[] = {5, 10, 15};
    int n = sizeof(v)/sizeof(v[0]);

    printf("test4: %d\n\n", unbounded_knapsack(max_weight, n, v, w));
}

int main()
{
    test1();
    test2();
    test3();
    test4();
    return 0;
}
