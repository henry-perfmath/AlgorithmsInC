#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "c_introsort.h"
#include<iostream>
#include<algorithm>
using namespace std;

// Number of elements to be sorted
#define N 1000000

// A comparator function used by qsort
int compare(const void * a, const void * b)
{
    return ( *(int*)a - *(int*)b );
}

/* C program for Merge Sort */
#include<stdlib.h>
#include<stdio.h>

// Merges two subarrays of arr[].
// First subarray is arr[l..m]
// Second subarray is arr[m+1..r]

void printArray(int A[], int size)
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", A[i]);
    printf("\n");
}

int main()
{
    int arr[N], dupArr[N];

    srand(time(NULL));

    clock_t begin, end;
    double time_spent;

    for (int i = 0; i < N; i++)
    	dupArr[i] = arr[i] = rand()%100000;

    //1. qsort
    begin = clock();
    qsort(arr, N, sizeof(int), compare);
    end = clock();
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    cout << "Time taken by C qsort() - "
         << time_spent << endl;
/*
    // 2. sort
    begin = clock();
    sort(dupArr, dupArr + N);
    end = clock();
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;

    cout << "Time taken by C++ sort() - "
         << time_spent << endl;
*/
	// 3. intr_sort
	begin = clock();
	intro_sort(dupArr, N);
	end = clock();
	time_spent = (double) (end - begin) / CLOCKS_PER_SEC;

	cout << "Time taken by intro_sort() - " << time_spent << endl;

	return 0;
}
