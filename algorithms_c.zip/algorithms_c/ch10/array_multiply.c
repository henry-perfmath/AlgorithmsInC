#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void array_multiply(int a[], int b[], int n)
{
	b[0] = 1;

	int sub = 1;
	for (int i = 1; i < n; i++) {
		sub *= a[i - 1];
		b[i] = sub;
	}

	sub = 1;
	for (int i = n - 1; i > 0; i--) {
		sub *= a[i];
		b[i - 1] *= sub;
	}
}

int main() {
	int n = 9, b[9];
	int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	int N = 10000000;

	clock_t start = clock();
	for (int i = 0; i < N; i++)
		array_multiply(a, b, n);
	double duration = (double) (clock() - start) / CLOCKS_PER_SEC;
	printf("duration = %f seconds\n", duration);

	printf("result:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", b[i]);
	}
	putchar('\n');
}
