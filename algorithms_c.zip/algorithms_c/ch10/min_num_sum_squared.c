#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

int min (int a, int b) {return (a < b) ? a : b;}

int get_min_items(int n)
{
	if (n < 1)
		return 0;

	int min_items = INT_MAX;
	int max_base = (int) sqrt(n);

	while (max_base > 0)
	{
		int items = 0;
		int sum = n;
		int base = max_base;

		while (sum > 0)
		{
			int x = sum / (base * base);
			items += x;
			sum = sum - x * base * base;
			--base;
		}

		if (items < min_items)
			min_items = items;
		max_base--;
	}

	return min_items;
}

int min_items_recur(int a[], int n, int V)
{
   if (V == 0) return 0;

   int min_items = INT_MAX;

   for (int i = 0; i < n; i++)
	   if (a[i] <= V)
		   min_items = min(min_items, 1 + min_items_recur(a, n, V - a[i]));

   return min_items ;
}

int min_items_dp(int a[], int n, int V) {

    int min_items[V + 1];

    min_items[0] = 0;
    for (int v = 1; v <= V; v++)
    	min_items[v] = INT_MAX;

	for (int v = 1; v <= V; v++) {
		for (int i = 0; i < n; i++) {
			int sup_vi = v - a[i];
			if (sup_vi >= 0) {
				int sub_sol = 1 + min_items[sup_vi];
				if (sub_sol < min_items[v]) {
					min_items[v] = sub_sol;
				}
			}
		}
	}

    return min_items[V];
}

void test1(int V) {
	printf("test1: min_num_items from get_min_items: %d\n", get_min_items(V));
}

void test2(int V) {
	int max_base = (int) sqrt(V);
	int a[max_base];
	for (int i = max_base; i >= 1; i--) {
		a[i - 1] = i * i;
		printf("i = %d, a[%d] = %d\n", i, i - 1, a[i - 1]);
	}

	printf("test2: min_num_items from min_items_recur: %d\n", min_items_recur(a, max_base, V));
}

void test3(int V) {
	int max_base = (int) sqrt(V);
	int a[max_base];
	for (int i = max_base; i >= 1; i--) {
		a[i - 1] = i * i;
		printf("i = %d, a[%d] = %d\n", i, i - 1, a[i - 1]);
	}

	printf("test3: min_num_items from min_num_dp: %d\n", min_items_dp(a, max_base, V));
}

int main() {
	int V, n;
	printf("enter V and n(1 - get_min_items, 2 - min_items_recur, and 3 - min_items_dp\n");
	scanf("%d %d", &V, &n);
	switch (n) {
		case 1:
			test1(V);
			break;
		case 2:
			test2(V);
			break;
		case 3:
			test3(V);
			break;
		default:
			printf("invalid n entered\n");
	}
}
