#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int reverse(int x) {
	int result = 0, remaining = abs(x);
	while(remaining) {
		result = result * 10 + remaining % 10;
		remaining /= 10;
	}
	return x < 0 ? -result : result;
}

int main() {
	printf("-413 is reversed to: %d\n", reverse(-413));
}
