#include <stdio.h>

int search(int n, int a[n][n], int m, int b[m]) {
	int i = 0, j = 0, k = 0;
	if (a[i][j] != b[k]) {
		return 0;
	} else {
		printf("b[k] = %d at i = %d, j = %d\n", b[k], i, j);
		k++;
	}

	while (i < n && j < n) {
		if ((j + 1) < n && a[i][j + 1] == b[k]) {
			j++;
			printf("b[k] = %d at i = %d, j = %d\n", b[k], i, j);
		} else if ((i + 1) < n && a[i + 1][j] == b[k]) {
			i++;
			printf("b[k] = %d at i = %d, j = %d\n", b[k], i, j);
		} else if ((i > 0) && (a[i - 1][j] == b[k])) {
			i--;
			printf("b[k] = %d at i = %d, j = %d\n", b[k], i, j);
		} else if (j > 0 && (a[i][j - 1] == b[k])) {
			j--;
			printf("b[k] = %d at i = %d, j = %d\n", b[k], i, j);
		} else if (k < m) {
			return 0;
		}
		k++;
		if (k == m) {
			return 1;
		}
	}
	return 0;
}

void test1() {
	// initialize a matrix and get the dimension
	int a[3][3] = {{1, 2, 3},
				   {3, 4, 5},
				   {5, 6, 7}};
	int n = sizeof(a[0]) / sizeof(a[0][0]);
	printf("n = %d\n", n);

	int m = 4;
	int b[] = {1, 3, 4, 6};
	printf("found = %d\n", search(n, a, m, b));
}
void test2() {
	// initialize a matrix and get the dimension
	int a[3][3] = {{1, 2, 3},
				   {3, 4, 5},
				   {5, 6, 7}};
	int n = sizeof(a[0]) / sizeof(a[0][0]);
	printf("n = %d\n", n);

	int m = 4;
	int b[] = {1, 3, 4, 2};
	printf("found = %d\n", search(n, a, m, b));
}

int main() {
	test1();
	test2();
}
