#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int MAX_ARRAY_SIZE = 15;

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

void selection_sort(int a[], int n)
{
    int i, j, min_idx;

    for (i = 0; i < n-1; i++)
    {
        min_idx = i;
        for (j = i+1; j < n; j++)
          if (a[j] < a[min_idx])
            min_idx = j;

        swap(&a[min_idx], &a[i]);
    }
}

void print_array(int a[], int size)
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", a[i]);
    printf("\n");
}

int main()
{
	srand(time(0));
	printf("before sorting:\n");
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % 30;
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}

    int n = sizeof(a)/sizeof(a[0]);
    selection_sort(a, n);
    printf("after sorting: \n");
    print_array(a, n);
    return 0;
}

