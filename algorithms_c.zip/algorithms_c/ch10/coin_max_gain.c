#include <stdio.h>
#include <stdlib.h>

int max (int a, int b) { return (a > b) ? a: b; }
int min (int a, int b) { return (a < b) ? a: b; }

int maxmin_strategy(int* a, int n)
{
	int max_gain[n][n];
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++) {
			max_gain[i][j] = (i == j) ? a[i] : 0;
		}

	for (int seq_end = 1; seq_end < n; ++seq_end) {
		for (int i = 0, j = seq_end; j < n; ++i, ++j) {
			int min1 = a[i] + min(max_gain[i + 2][j], max_gain[i + 1][j - 1]);
			int min2 = a[j];
			if (j >= 2)
				min2 += min(max_gain[i + 1][j - 1], max_gain[i][j - 2]);
			max_gain[i][j] = max(min1, min2);
		}
	}
	return max_gain[0][n - 1];
}

void test1() {
	int a[] = { 10, 25, 1, 5};
	int n = sizeof(a) / sizeof(a[0]);
	printf("test1: %d\n", maxmin_strategy(a, n));

}
int main()
{
	test1();
	return 0;
}

