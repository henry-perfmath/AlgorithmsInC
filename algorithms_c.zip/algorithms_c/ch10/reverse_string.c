#include <stdio.h>
#include <string.h>

void swap(char *x, char *y) {
	char tmp;
	tmp = *x;
	*x = *y;
	*y = tmp;
}

// mirror swapping
// c version: must pass in address via &. different from c++
void reverse1(char *str) {
	int n = strlen (str);
	for (int i = 0; i < n / 2; i++)swap (&str[i], &str[n - i - 1]);

}
// pointer arithmetic
//In C pointers can be compared if the two pointers are pointing to the same array.
void reverse2(char *str) {
	char *end = str;

	if (str) {
		// move end to the end
		while (*end) {
			++end;
		}
		--end; // back up one
		printf("before swap: str=%s, end=%s\n", str, end);

		char tmp;
		while (str < end) {
			printf("during swap: *str=%c, *end=%c\n", *str, *end);
			tmp = *str;
			*str = *end;
			*end = tmp;
			str++;
			end--;
		}
		printf("after swap: str=%s, end=%s\n", str, end);
	}
}
int main() {
	char str[20] = "This is a test";
	char original[20];
	strcpy(original, str);

	printf("initial: %s\n", str);
	reverse2 (str);
	//reverse1 (str);

	printf("afetr: %s <==>%s\n", str, original);
	return 0;
}








