#include <stdio.h>
#include "max_heap.h"
#define MAX_CAPACITY 100
//int heap[MAX_CAPACITY ] = {150, 80, 40, 30, 10, 70, 110, 100, 20, 90, 60, 50, 120, 140, 130}; // remaining set to 0's
int heap[MAX_CAPACITY ] = {15, 150, 80, 40, 30, 60, 70, 110, 100, 20, 90, 10, 50, 120, 140, 130}; // remaining set to 0's
int main() {

	//build_max_heap(heap);
	heapify (heap); //heapify an array initialized at the start

	print_heap(heap, "before insert");

	printf("\n===insert===\n");
	insert(heap, 15);
	print_heap(heap, "after insert 15");

	int max_val = delete_max(heap);
	printf("\ndelete_max: max_val = %d\n", max_val);
	print_heap(heap, "after delete_max");

	print_heap(heap, "before sort_asc");
	heap_sort_asc(heap);
	print_heap(heap, "after sort_asc");

	reverse_to_desc (heap);
	print_heap(heap, "after reverse");
}

