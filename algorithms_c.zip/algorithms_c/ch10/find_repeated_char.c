#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_CHAR 256

char find_repeated_first_char(char* str)
{
	int count[MAX_CHAR] = {0};
	int n = strlen(str);
	for (int i = 0; i < n; i++) {
		int char_val = (int) str[i] - ' '; // SP is the first char with an integer value of 32
		if (char_val < 0) continue;
		if (count[char_val] == 0)
			count[char_val] = char_val;
		else
			return str[i];
	}

    return '\0';
}

int main()
{
    //char str[] = "This is a test";
	char input_str[MAX_CHAR]  = {0};
	//scanf("%s", input_str); // stops at the first space encountered
	//gets(input_str); // unsafe
	printf("Entered a string ....\n");
	fgets(input_str, MAX_CHAR, stdin);
	printf("Entered: %s\n", input_str);
	char found = find_repeated_first_char(input_str);
	if(found)
		printf("found the first repeated char: %c\n", found);
	else
		printf("no repeated char found\n");

}

