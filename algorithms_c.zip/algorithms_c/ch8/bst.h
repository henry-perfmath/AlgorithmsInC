#include<stdio.h>
#include<stdlib.h>
#ifndef BST_H
#define BST_H
typedef struct node
{
    int key;
    struct node *left, *right;
} Node;
#endif

Node *make_node(int item);
void preorder(Node *node);
void inorder(Node *node);
void postorder(Node *node);
Node *insert(Node *node, int key);
void clear (Node *node);
