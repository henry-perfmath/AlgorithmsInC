#include <stdio.h>
#include <stdlib.h>
#include "bst_queue.h"
#include "bst.h"
#include <stdbool.h>
#ifndef BOOL_H
#define BOOL_H
#endif

void init(Queue *queue)
{
    queue->front = queue->rear = NULL;
    queue->length = 0;
}

bool is_full(const Queue *queue)
{
    return queue->length == MAXQUEUE;
}

bool is_empty(const Queue *queue)
{
    return queue->length == 0;
}

int queue_length(const Queue *queue)
{
    return queue->length;
}

bool enqueue(Node node, Queue *queue)
{
    if (is_full(queue))
        return false;

    QNode *new_node = (QNode *) malloc( sizeof(QNode));
    if (!new_node)
    {
        fprintf(stderr,"Unable to allocate memory!\n");
        exit(1);
    }
    new_node->node = node;
    new_node->next = NULL;

    if (is_empty(queue))
        queue->front = new_node;
    else
        queue->rear->next = new_node;

    queue->rear = new_node; // remark the rear
    queue->length++;
    
    return true;
}


bool dequeue(Node *node, Queue *queue)
{
	if (is_empty(queue))
        return false;

    *node = queue->front->node;

    QNode *temp = queue->front;
    queue->front = queue->front->next;
    free(temp);
    queue->length--;

    if (queue->length == 0)
        queue->rear = NULL;
    
    return true;
}

void traverse(const Queue *queue, void (*func_ptr)(Node node))
{
    QNode *cursor = queue->front;
    while (cursor != NULL)
    {
        (*func_ptr)(cursor->node);
        cursor = cursor->next;
    }
}

void q_clear(Queue *queue)
{
    Node dummy;
    while (!is_empty(queue))
        dequeue(&dummy, queue);
}
