#include<stdio.h>
#include<stdlib.h>

// An AVL tree node
typedef struct node
{
	int key;
	struct node *left;
	struct node *right;
	int height;
} Node;

int max(int a, int b);

int height(Node *N)
{
	if (N == NULL) // check corner case
		return 0;
	return N->height;
}

int max(int a, int b)
{
	return (a > b)? a : b;
}

Node* newNode(int key)
{
	Node* node = (Node*) malloc(sizeof(Node));
	node->key = key;
	node->left = NULL;
	node->right = NULL;
	node->height = 1; // new node is initially added at leaf
	return(node);
}

Node *rightRotate(Node *y)
{
	Node *x = y->left;
	Node *T2 = x->right;

	// Perform rotation
	x->right = y;
	y->left = T2;

	// Update heights
	y->height = max(height(y->left), height(y->right)) + 1;
	x->height = max(height(x->left), height(x->right)) + 1;

	// Return new root
	return x;
}

Node *leftRotate(Node *x)
{
	Node *y = x->right;
	Node *T2 = y->left;

	// Perform rotation
	y->left = x;
	x->right = T2;

	// Update heights
	x->height = max(height(x->left), height(x->right)) + 1;
	y->height = max(height(y->left), height(y->right)) + 1;

	// Return new root
	return y;
}

// Get Balance factor of node N
int getBalance(Node *N)
{
	if (N == NULL)
		return 0;
	return height(N->left) - height(N->right);
}

// Recursive function to insert a key in the subtree rooted
// with node and returns the new root of the subtree.
Node* insert(Node* node, int key)
{
	/* 1. Perform the normal BST insertion */
	if (node == NULL)
		return(newNode(key));

	if (key < node->key)
		node->left = insert(node->left, key);
	else if (key > node->key)
		node->right = insert(node->right, key);
	else // Equal keys are not allowed in BST
		return node;

	/* 2. Update height of this ancestor node */
	node->height = 1 + max(height(node->left), height(node->right));

	/* 3. Get the balance factor of this ancestor
		node to check whether this node became
		unbalanced */
	int balance = getBalance(node);

	// If this node becomes unbalanced, then
	// there are 4 cases: 2 single rotation cases and 2 double rotation cases

	// single rotataion case 1: Left Left Case
	if (balance > 1 && key < node->left->key)
		return rightRotate(node);

	// single rotation case 2: Right Right Case
	if (balance < -1 && key > node->right->key)
		return leftRotate(node);

	// double rotation case 1: Left Right Case
	if (balance > 1 && key > node->left->key)
	{
		node->left = leftRotate(node->left);
		return rightRotate(node);
	}

	// double rotation case 2: Right Left Case
	if (balance < -1 && key < node->right->key)
	{
		node->right = rightRotate(node->right);
		return leftRotate(node);
	}

	/* return the (unchanged) node pointer */
	return node;
}

void preOrder(Node *root)
{
	if(root != NULL)
	{
		printf("%d ", root->key);
		preOrder(root->left);
		preOrder(root->right);
	}
}

void test1() {
	int a[] = {10, 20, 30, 40, 50, 25}; // original
	int n = sizeof(a) / sizeof(a[0]);

	Node *root = NULL;
	for (int i = 0; i < n; i++) {
		root = insert(root, a[i]);
	}

	/* The constructed AVL Tree would be
			30
			/ \
			20 40
			/ \	 \
			10 25 50
	*/

	printf("\ntest1: Preorder traversal of the  AVL tree: \n");
	preOrder(root);
}

void test2() { // Weiss p 145
	int a[] = {10, 20, 30, 40, 50, 60, 70, 150, 140, 130, 120, 110, 100, 90, 80, 85}; // original
	int n = sizeof(a) / sizeof(a[0]);

	Node *root = NULL;
	for (int i = 0; i < n; i++) {
		root = insert(root, a[i]);
	}
	printf("\ntest2: Preorder traversal of the AVL tree: \n");
	preOrder(root);
	/*
	7
	4 12
	2 6 10 14
	1 3 5 * 8.5 11 13 15
	* * * * 8 	9 * * *
	*/
}

int main()
{
	test1();
	test2();
}

