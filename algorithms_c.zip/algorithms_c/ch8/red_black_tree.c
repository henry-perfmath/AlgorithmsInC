#include<stdio.h>
#include<stdlib.h>

//A Red-Black tree node structure
typedef struct node
{
    int data;
    char color;
    struct node *left, *right, *parent;
} Node;

void swap_char(char *a, char *b) {
	char tmp = *a;
	*a = *b;
	*b = tmp;
}

// Left Rotation
void rotateLeft(Node **root, Node *pt)
{
    //pt_right stored pointer of right child of pt
    Node *pt_right = pt->right;

    //store pt_right's left subtree's pointer as pt's right child
    pt->right = pt_right->left;

    //update parent pointer of pt's right
    if (pt->right != NULL)
        pt->right->parent = pt;

    //update pt_right's parent pointer
    pt_right->parent = pt->parent;

    // if pt's parent is null make pt_right as root of tree
    if (pt->parent == NULL)
        (*root) = pt_right;

    // store pt_right at the place of pt
    else if (pt == pt->parent->left)
        pt->parent->left = pt_right;
    else    pt->parent->right = pt_right;

    // make pt as left child of pt_right
    pt_right->left = pt;

    //update parent pointer of pt
    pt->parent = pt_right;
}


// Right Rotation (Similar to rotateLeft)
void rotateRight(Node **root, Node *pt)
{
    Node *pt_left = pt->left;
    pt->left = pt_left->right;
    if (pt_left->right != NULL)
        pt_left->right->parent = pt;
    pt_left->parent =pt->parent;
    if (pt_left->parent == NULL)
        (*root) = pt_left;
    else if (pt == pt->parent->left)
        pt->parent->left = pt_left;
    else pt->parent->right = pt_left;
    pt_left->right = pt;
    pt->parent = pt_left;
}

void insertFixUp(Node **root, Node *pt)
{
	Node *parent_pt = NULL;
	Node *grand_parent_pt = NULL;
	// do not do anything if (1) pt is root, (2) pt color is Black, and (3) pt's parent color is not RED (no RED property to violate)
	while ((pt != *root) && (pt->color != 'B') &&
		(pt->parent->color == 'R'))
	{

		parent_pt = pt->parent;
		grand_parent_pt = pt->parent->parent;

		/* Case : A
			Parent of pt is left child of Grand-parent of pt */
		if (parent_pt == grand_parent_pt->left)
		{

			Node *uncle_pt = grand_parent_pt->right;

			/* Case : 1
			The uncle of pt is also red
			Only Recoloring required */
			if (uncle_pt != NULL && uncle_pt->color == 'R')
			{
				grand_parent_pt->color = 'R';
				parent_pt->color = 'B';
				uncle_pt->color = 'B';
				pt = grand_parent_pt;
			}

			else
			{
				/* Case : 2
				pt is right child of its parent
				Left-rotation required */
				if (pt == parent_pt->right)
				{
					rotateLeft(root, parent_pt);
					pt = parent_pt;
					parent_pt = pt->parent;
				}

				/* Case : 3
				pt is left child of its parent
				Right-rotation required */
				rotateRight(root, grand_parent_pt);

				// swap color
				swap(&parent_pt->color, &grand_parent_pt->color);
				pt = parent_pt;
			}
		}

		/* Case : B
		Parent of pt is right child of Grand-parent of pt */
		else
		{
			Node *uncle_pt = grand_parent_pt->left;

			/* Case : 1
				The uncle of pt is also red
				Only Recoloring required */
			if ((uncle_pt != NULL) && (uncle_pt->color == 'R'))
			{
				grand_parent_pt->color = 'R';
				parent_pt->color = 'B';
				uncle_pt->color = 'B';
				pt = grand_parent_pt;
			}
			else
			{
				/* Case : 2
				pt is left child of its parent
				Right-rotation required */
				if (pt == parent_pt->left)
				{
					rotateRight(root, parent_pt);
					pt = parent_pt;
					parent_pt = pt->parent;
				}

				/* Case : 3
				pt is right child of its parent
				Left-rotation required */
				rotateLeft(root, grand_parent_pt);
				swap_char(&parent_pt->color, &grand_parent_pt->color);
				pt = parent_pt;
			}
		}
	}

	(*root)->color = 'B';
}

void insert(Node **root, int data)
{
    // Allocate memory for new node
    Node *z = (Node*)malloc(sizeof(Node));
    z->data = data;
    z->left = z->right = z->parent = NULL;

     //if root is null make z as root
    if (*root == NULL)
    {
        z->color = 'B';
        (*root) = z;
    }
    else
    {
        Node *y = NULL;
        Node *x = (*root);

        // Follow standard BST insert steps to first insert the node
        while (x != NULL)
        {
            y = x;
            if (z->data < x->data)
                x = x->left;
            else
                x = x->right;
        }
        z->parent = y;
        if (z->data > y->data)
            y->right = z;
        else
            y->left = z;
        z->color = 'R';

        // call insertFixUp to fix reb-black tree's property if it
        // is voilated due to insertion.
        insertFixUp(root, z);
    }
}

void inorder(Node *root)
{
    if (root == NULL)
        return;
    inorder(root->left);
    printf("%d (%c) ", root->data, root->color);
    inorder(root->right);
}

void test2()
{
    Node *root = NULL; // functions expecting to change root use Node **root, with root passed in as &root
    //int a[] = {27, 22, 15, 11, 13, 8, 17, 6, 25, 1};
    int a[] = {1, 6, 8, 11, 13, 15, 17, 22, 25, 27}; // henry
    int n = sizeof(a)/sizeof(a[0]);
    for (int i = 0; i < n; i++) {
    	insert(&root, a[i]);
    }
    printf("\nTest2: Tree inorder traversal: ");
    inorder(root);

}

void test1()
{
    Node *root = NULL;
    int a[] = {10, 20, 40, 30, 50, 35, 25, 37};
    int n = sizeof(a)/sizeof(a[0]);
    for (int i = 0; i < n; i++) {
    	insert(&root, a[i]);
    }
    printf("\nTest1: Tree inorder traversal: ");
    inorder(root);

}

int main()
{
	test1();
    test2();
    //return 0; // not necessary
}

