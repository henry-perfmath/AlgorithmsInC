/*
 *
 */

#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

void print_heap(char *header, int a[], int n);

void swap(int *x, int *y) {
	*x ^= *y;
	*y ^= *x;
	*x ^= *y;
}

void max_perc_down_swap(int *a, int n, int p_idx) {
	int largest = p_idx;
	int c_idx = 2 * p_idx + 1;

	if (c_idx < n && a[c_idx] > a[p_idx])
		largest = c_idx;

	int larger_c_idx = c_idx + 1;
	if (larger_c_idx < n && a[larger_c_idx] > a[largest])
		largest = larger_c_idx;

	if (largest != p_idx)
	{
		swap(&a[p_idx], &a[largest]);
		max_perc_down_swap(a, n, largest);
	}
}

void build_max_heap(int *a, int n)  {
	for (int p_idx = n / 2 - 1; p_idx >= 0; --p_idx)
		max_perc_down_swap(a, n, p_idx);
}

void max_heap_sort(int *a, int n) {

	build_max_heap(a, n);

	for (int i = n - 1; i > 0; --i)
	{
		swap(&a[0], &a[i]);
		--n;
		max_perc_down_swap(a, n, 0);
	}
}

/*
 * min_heapify with no swap and non-recursive - perc_down only
 */
void min_perc_down(int a[], int n, int p_idx) { // Weiss p 262
	int p_item = a[p_idx];
	//int c_idx;
	//while (2 * p_idx + 1 < n) { // left child within heap size
	while (p_idx < (n - 1) /2) { // left child within heap size
		int c_idx = 2 * p_idx + 1;
		if ((c_idx + 1) < n && a[c_idx + 1] < a[c_idx]) // must check c_idx
			c_idx++;
		if (p_item > a[c_idx]) {
			a[p_idx] = a[c_idx];
		} else
			break;
		p_idx = c_idx;
	}
	a[p_idx] = p_item;
}

void build_min_heap(int a[], int n) { // start from the last parent node
	for (int p_idx = n / 2 - 1; p_idx >= 0; --p_idx) {
		min_perc_down(a, n, p_idx);
	}
}

void min_heap_sort(int a[], int n)
{
	//for (int i = (n - 1) / 2; i > 0; --i) // build heap
	//	perc_down(a, n, i);
	build_min_heap(a, n);

	for (int i = n - 1; i > 0; --i)
	{
		swap(&a[i], &a[0]);
		--n;
		//min_perc_down(a, i - 1, 0);
		min_perc_down(a, n, 0);
	}
}

void min_insert(int a[], int *n, int x) // percolate up
{
	++*n;

	a[*n - 1] = x;
	build_min_heap(a, *n);
}

int delete_min(int a[], int *n) {
	int min_val = a[0];
	a[0] = a[*n - 1];
	--*n;
	build_min_heap(a, *n);
	return min_val;
}

void print_heap(char *header, int a[], int n) {
	printf("\n... %s \n", header);
	int level = 0;
	for (int i = 0; i < n; i++) {
		if ((int) log2(i + 1) > level) {
			putchar('\n');
			level = (int) log2(i + 1) ;
		}
		printf("%d ", a[i]);
	}
	printf("\n");
}

void test3() {
	int N = 1000000;
    int a[N];

    srand(time(NULL));

    clock_t begin, end;
    double time_spent;

    for (int i = 0; i < N; i++)
    	a[i] = rand()%(2 * N);

    begin = clock();
   	//min_heap_sort(a, N);
   	max_heap_sort(a, N);
    end = clock();
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Time taken by max_heap_sort(): %f ", time_spent);
}

void test2() {
	int N = 1000000;
    int a[N];

    srand(time(NULL));

    clock_t begin, end;
    double time_spent;

    for (int i = 0; i < N; i++)
    	a[i] = rand()%(2 * N);

    begin = clock();
   	min_heap_sort(a, N);
   	//max_heap_sort(a, N);
    end = clock();
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Time taken by min_heap_sort(): %f ", time_spent);
}

void test1() {

	int a[] = {150, 80, 40, 30, 60, 70, 110, 100, 20, 90, 10, 50, 120, 140, 130};
	int n = sizeof(a)/sizeof(a[0]);
	print_heap("min-heap: before build_min_heap", a, n);
	build_min_heap (a, n); //heapify an array initialized at the start

	print_heap("min_heap: after build_min_heap", a, n);

	printf("\n===insert===\n");
	min_insert(a, &n, 15);
	print_heap("after insert 15", a, n);

	int min_val = delete_min(a, &n);
	printf("\ndelete_min: min_val = %d\n", min_val);
	print_heap("after delete_min", a, n);

	print_heap("before min_heap_sort", a, n);
	min_heap_sort(a, n);
	print_heap("after min_heap_sort", a, n);
}

void test0() {

	int a[] = {150, 80, 40, 30, 60, 70, 110, 100, 20, 90, 10, 50, 120, 140, 130};
	int n = sizeof(a)/sizeof(a[0]);
	print_heap("before max_heap_sort", a, n);
	max_heap_sort (a, n); //heapify an array initialized at the start

	print_heap("after max_heap_sort", a, n);
}

int main() {
	test0();
	test1();
	test2();
	test3();
}
