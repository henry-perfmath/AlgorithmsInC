/*
 * bst.c
 *
 *  Created on: Feb 13, 2018
 *      Author: henryliu
 */

#include<stdio.h>
#include<stdlib.h>
#include "bst.h"

int max (int a, int b)
{
	return (a > b) ? a : b;
}


int tree_levels(Node *node)
{
    if (node == NULL)
        return 0;
    else
    	return 1 + max(tree_levels(node->left), tree_levels(node->right));
}

void print_level(Node *node, int level)
{
    if (node == NULL)
        return;
    if (level == 1)
        printf("%d ", node->key);

    print_level(node->left, level - 1);
    print_level(node->right, level - 1);
}

void BFT(Node *node)
{
    int num_of_levels = tree_levels(node);

    for (int i = 1; i <= num_of_levels; i++)
    	print_level(node, i);
}

int main()
{
    Node *root = NULL;
    root = insert(root, 50); // first call must return root

    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);

    insert(root, 15);
    insert(root, 25);
    // print depth_first_Traversal traversal of the BST
    printf("inorder... ");
    inorder(root);
    printf("\npreorder... ");
    preorder(root);
    printf("\npostorder... ");
    postorder(root);
    printf("\nBFT ... \n");
    BFT(root);
    printf("\nclear ... ");

    clear(root);
    return 0;
}
