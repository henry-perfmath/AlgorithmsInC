#ifndef _QUEUE_H_
#define _QUEUE_H_
#include <stdbool.h>
#include "bst.h"

#define MAXQUEUE 100

typedef struct qnode
{
    Node node;
    struct qnode *next;
} QNode;

typedef struct queue
{
    struct qnode *front;
    struct qnode *rear;
    int length;
} Queue;

void init(Queue *queue);
bool is_full(const Queue *queue);
bool is_empty(const Queue *queue);
int  queue_length(const Queue *queue);
void traverse(const Queue *queue, void (* func_ptr)(Node node));
bool enqueue(Node node, Queue *queue);
bool dequeue(Node *node, Queue *queue);
void q_clear(Queue *queue);

#endif
