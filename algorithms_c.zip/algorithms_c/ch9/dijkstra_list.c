#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

#include "my_queue.h"

typedef struct AdjListNode
{
	int dest;
	int weight;
	struct AdjListNode *next;
} AdjListNode;

typedef struct AdjList
{
	struct AdjListNode *head;
} AdjList;

typedef struct Graph
{
	int V; // # of vertices
	struct AdjList *adjListArray;
} Graph;

typedef struct MinHeapNode
{
	int idx;
	int dist;
} MinHeapNode;

typedef struct MinHeap
{
	int size;
	int capacity;
	int *pos;
	struct MinHeapNode **array;
} MinHeap;

void printMinHeap(MinHeap *minHeap) {
	int V = minHeap->size;
	for (int v = 0; v < V; v++) {
		int idx = minHeap->array[v]->idx;
		int dist = minHeap->array[v]->dist;
		printf("minHeap: v = %d, vertex = %d, dist = %d\n", v, idx, dist);
	}
}

AdjListNode* createAdjListNode(int dest, int weight)
{
	AdjListNode *node = (AdjListNode*) malloc(sizeof(AdjListNode));
	node->dest = dest;
	node->weight = weight;
	node->next = NULL;
	return node;
}

Graph* createGraph(int V)
{
	Graph* graph = (Graph *) malloc(sizeof(Graph));
	graph->V = V;

	graph->adjListArray = (AdjList*) malloc(V * sizeof(AdjList));

	for (int i = 0; i < V; ++i)
		graph->adjListArray[i].head = NULL;

	return graph;
}

void addEdge(Graph *graph, int origin, int dest, int weight)
{
	AdjListNode* destNode = createAdjListNode(dest, weight);
	destNode->next = graph->adjListArray[origin].head;
	graph->adjListArray[origin].head = destNode;

	AdjListNode* originNode = createAdjListNode(origin, weight);
	originNode->next = graph->adjListArray[dest].head;
	graph->adjListArray[dest].head = originNode;
}

MinHeapNode* createMinHeapNode(int idx, int dist)
{
	MinHeapNode* minHeapNode = (MinHeapNode*) malloc(sizeof(MinHeapNode));
	minHeapNode->idx = idx;
	minHeapNode->dist = dist;
	return minHeapNode;
}

MinHeap* createMinHeap(int capacity)
{
	MinHeap* minHeap = (MinHeap*) malloc(sizeof(MinHeap));
	minHeap->pos = (int *)malloc(capacity * sizeof(int));
	minHeap->size = 0;
	minHeap->capacity = capacity;
	minHeap->array =
		(MinHeapNode**) malloc(capacity * sizeof( MinHeapNode*));
	return minHeap;
}

void swapMinHeapNode(MinHeapNode **a, MinHeapNode **b)
{
	MinHeapNode* t = *a;
	*a = *b;
	*b = t;
}

void minHeapify(MinHeap *minHeap, int idx)
{
	int smallest, left, right;
	smallest = idx;
	left = 2 * idx + 1;
	right = 2 * idx + 2;

	if (left < minHeap->size && minHeap->array[left]->dist < minHeap->array[smallest]->dist )
		smallest = left;

	if (right < minHeap->size && minHeap->array[right]->dist < minHeap->array[smallest]->dist )
		smallest = right;

	if (smallest != idx)
	{
		MinHeapNode *smallestNode = minHeap->array[smallest];
		MinHeapNode *idxNode = minHeap->array[idx];

		minHeap->pos[smallestNode->idx] = idx;
		minHeap->pos[idxNode->idx] = smallest;

		swapMinHeapNode(&minHeap->array[smallest], &minHeap->array[idx]);

		minHeapify(minHeap, smallest);
	}
}

MinHeapNode* extractMin(MinHeap *minHeap)
{
	if (minHeap->size == 0)
		return NULL;

	MinHeapNode* root = minHeap->array[0];
	MinHeapNode* lastNode = minHeap->array[minHeap->size - 1];
	minHeap->array[0] = lastNode;

	minHeap->pos[root->idx] = minHeap->size-1;
	minHeap->pos[lastNode->idx] = 0;

	--minHeap->size;
	minHeapify(minHeap, 0);

	return root;
}

void decreaseKey(MinHeap *minHeap, int idx, int dist)
{
	int i = minHeap->pos[idx];

	minHeap->array[i]->dist = dist;

	int parentIndex = (i - 1) / 2;
	while (i && minHeap->array[i]->dist < minHeap->array[parentIndex]->dist)
	{
		minHeap->pos[minHeap->array[i]->idx] = parentIndex;
		minHeap->pos[minHeap->array[parentIndex]->idx] = i;
		swapMinHeapNode(&minHeap->array[i], &minHeap->array[parentIndex]);

		i = parentIndex;
		parentIndex = (i - 1) / 2;
	}
}

void printDistArray(int dist[], int n)
{
	printf("Vertex Distance from Source 0\n");
	for (int i = 0; i < n; ++i)
		printf("%d \t\t %d\n", i, dist[i]);
}

MinHeap *initMinHeap(int n) {
	MinHeap* minHeap = createMinHeap(n);

	for (int idx = 0; idx < n; ++idx)
	{
		minHeap->array[idx] = createMinHeapNode(idx, INT_MAX);
		minHeap->pos[idx] = idx;
	}

	minHeap->size = n;
	return minHeap;
}
void dijkstra(Graph *graph, int origin)
{
	int V = graph->V;
	int dist[V];

	for (int idx = 0; idx < V; idx++) {
		dist[idx] = INT_MAX;
	}

	MinHeap* minHeap = initMinHeap(V);
	dist[origin] = 0;
	decreaseKey(minHeap, origin, dist[origin]);

	while (minHeap->size > 0)
	{
		int origin_idx = extractMin(minHeap)->idx;
		AdjListNode* adjListHead = graph->adjListArray[origin_idx].head;

		while (adjListHead != NULL)
		{
			int weight = adjListHead->weight;
			int dest = adjListHead->dest;
			if ((dist[origin_idx] + weight) < dist[dest])
			{
				dist[dest] = dist[origin_idx] + weight;
				decreaseKey(minHeap, dest, dist[dest]);
			}
			adjListHead = adjListHead->next;
		}
	}

	printDistArray(dist, V);
}

void printAdjListArray(const Graph *graph) {
	int n = graph->V;
	printf("graph size = %d\n", n);
	for (int i = 0; i < n; i++) {
		AdjListNode *node  = graph->adjListArray[i].head; // use . not ->
		printf("adjacent nodes for i = %d\n", i);
		while (node != NULL) {
			printf("node %d (%d) | ", node->dest, node->weight);
			node = node->next;
		}
		putchar('\n');
	}
}

void bft(Graph *graph) {
	int n = graph->V;
	int visited[n], enqueued[n]; // need 2 state arrays
	for (int i = 0; i < n; i++) {
		visited[i] = false;
		enqueued[i] =  false;
	}
	printf("bft with graph size = %d\n", n);
	Queue queue;
	init(&queue);
	int origin = 0;
	Item item;
	item.data = origin;
	enqueue(&queue, item);
	Item *item_ptr = (Item *)malloc(sizeof(Item)); // must allocate memory

	while (!is_empty(&queue)) {
		dequeue(&queue, item_ptr);
		int origin = item_ptr->data;
		if(!visited[origin]) {
			printf("%d ", origin);
			visited[origin] = true;
		}

		AdjListNode *node  = graph->adjListArray[origin].head;
		while (node != NULL) {
			item.data = node->dest;
			if(!visited[item.data] && !enqueued[item.data]) {
				enqueue(&queue, item);
				enqueued[item.data] = true;
			}
			node = node->next;
		}
	}
	free(item_ptr);
	putchar('\n');
}

int main()
{
	int V = 9;
	Graph *graph = createGraph(V);
	addEdge(graph, 0, 1, 4);
	addEdge(graph, 0, 7, 8);
	addEdge(graph, 1, 2, 8);
	addEdge(graph, 1, 7, 11);
	addEdge(graph, 2, 3, 7);
	addEdge(graph, 2, 8, 2);
	addEdge(graph, 2, 5, 4);
	addEdge(graph, 3, 4, 9);
	addEdge(graph, 3, 5, 14);
	addEdge(graph, 4, 5, 10);
	addEdge(graph, 5, 6, 2);
	addEdge(graph, 6, 7, 1);
	addEdge(graph, 6, 8, 6);
	addEdge(graph, 7, 8, 7);
	printAdjListArray(graph);

	dijkstra(graph, 0);
	bft(graph);
	return 0;
}
