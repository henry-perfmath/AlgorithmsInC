/*
 * search_pad.c
 *
 *  Created on: Dec 10, 2018
 *  Knight's dial
 */
/*
#include <stdio.h>
#include <stdbool.h>

#define M 4
#define N 3
*/
#include "knights_dialer.h"
ValidMoves *moves;
int move_it(int pad[M][N], int x);

void get_index (int x, int *i, int *j) {
	if (x < 0 || x == 10 || x == 12) {
		*i = *j = -1;
	} else {
		*i = (x - 1) / 3;
		*j = (x - 1) % 3;
	}
}

int get_digit(int x) {
	if (x <= 9) {
		return x;
	} else if (x == 11) {
		return 0;
	} else {
		return -1;
	}
}

void print_hop(int hop[N])
{
	for (int i = 0; i < N; i++)
	{
			printf(" %d ", hop[i]);
			if ( i < (N - 1))
				printf(" -> ");
	}
	printf("\n");
}

bool is_a_valid_key(int x)
{
	if(x != 10 && x != 12)
		return true;
	return false;
}

bool is_a_valid_point(int x)
{
	int i, j;
	get_index (x, &i, &j);
	if(is_a_valid_key (x) && i >= 0 && i < M && j >= 0 && j < N)
		return true;
	return false;
}

bool is_a_valid_move(int x, int y)
{
	int x_i, x_j, y_i, y_j;
	get_index (x, &x_i, &x_j);
	get_index (y, &y_i, &y_j);
	if(is_a_valid_point(x) && is_a_valid_point(y) && (x_i == y_i || x_j == y_j))
		return true;
	return false;
}
/*
bool move_up(int x) {
	int i, j;
	get_index(x, &i, &j);
	int y = (i - 1) * 3 + j;
	if (is_a_valid_move(y))
		return true;
	else
		return false;
}

bool move_down(int x) {
	int i, j;
	get_index(x, &i, &j);
	int y = (i + 1) * 3 + j;
	if (is_a_valid_move(y))
		return true;
	else
		return false;
}

bool move_left(int x) {
	int i, j;
	get_index(x, &i, &j);
	int y = i * 3 + j - 1;
	if (is_a_valid_move(y))
		return true;
	else
		return false;
}

bool move_right(int x) {
	int i, j;
	get_index(x, &i, &j);
	int y = i * 3 + j + 1;
	if (is_a_valid_move(y))
		return true;
	else
		return false;
}
*/
void solver(int pad[M][N], int x)
{
	int hops = move_it(pad, x);
	moves[x - 1].count = hops;
	printf("\nx = %d: # of hops = %d\n", x, hops);
}

int move_it(int pad[M][N], int x)
{
	int hops = 0;

	//1. 1 up + 2 left's
	if (is_a_valid_move(x, x - 3) && is_a_valid_move(x - 3, x - 3 - 1) && is_a_valid_move(x - 3 - 1, x - 3 - 2)) {
		//printf("1. move %d -> %d -> %d -> %d ok\n", x, x - 3, x - 4, x - 5);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x - 3;
		moves[x - 1].seq[hops].p2 = x - 4;
		moves[x - 1].seq[hops].end = x - 5;
		moves[x - 1].count++;
		hops++;
	}

	//2. 1 up + 2 right's
	if (is_a_valid_move(x, x - 3) && is_a_valid_move(x - 3, x - 3 + 1) && is_a_valid_move(x - 3 + 1, x - 3 + 2)) {
		//printf("2. move %d -> %d -> %d -> %d ok\n", x, x - 3, x - 2, x - 1);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x - 3;
		moves[x - 1].seq[hops].p2 = x - 2;
		moves[x - 1].seq[hops].end = x - 1;
		moves[x - 1].count++;
		hops++; // up
	}

	//3. 1 down + 2 left's
	if (is_a_valid_move(x, x + 3) && is_a_valid_move(x + 3, x + 3 - 1) && is_a_valid_move(x + 3 - 1, x + 3 - 2)) {
		//printf("3. move %d -> %d -> %d -> %d ok\n", x, x + 3, x + 2, x + 1);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x + 3;
		moves[x - 1].seq[hops].p2 = x + 2;
		moves[x - 1].seq[hops].end = x + 1;
		moves[x - 1].count++;
		hops++;
	}

	//4. 1 down + 2 right's
	if (is_a_valid_move(x, x + 3) && is_a_valid_move(x + 3, x + 3 + 1) && is_a_valid_move(x + 3 + 1, x + 3 + 2)) {
		//printf("4. move %d -> %d -> %d -> %d ok\n", x, x + 3, x + 4, x + 5);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x + 3;
		moves[x - 1].seq[hops].p2 = x + 4;
		moves[x - 1].seq[hops].end = x + 5;
		moves[x - 1].count++;
		hops++;
	}

	//5. 1 left + 2 up's
	if (is_a_valid_move(x, x - 1) && is_a_valid_move(x - 1, x - 1 - 3) && is_a_valid_move(x - 1 - 3, x - 1 - 6)) {
		//printf("5. move %d -> %d -> %d -> %d ok\n", x, x - 1, x - 4, x - 5);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x - 1;
		moves[x - 1].seq[hops].p2 = x - 4;
		moves[x - 1].seq[hops].end = x - 5;
		moves[x - 1].count++;
		hops++;
	}

	//6. 1 left + 2 down's
	if (is_a_valid_move(x, x - 1) && is_a_valid_move(x - 1 , x - 1 + 3) && is_a_valid_move(x - 1 + 3, x - 1 + 6)) {
		//printf("6. move %d -> %d -> %d -> %d ok\n", x, x - 1, x + 2, x + 5);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x - 1;
		moves[x - 1].seq[hops].p2 = x + 2;
		moves[x - 1].seq[hops].end = x + 5;
		moves[x - 1].count++;
		hops++;
	}

	//7. 1 right + 2 up's
	if (is_a_valid_move(x, x + 1) && is_a_valid_move(x + 1, x + 1 - 3) && is_a_valid_move(x + 1 - 3, x + 1 - 6)) {
		//printf("7. move %d -> %d -> %d -> %d ok\n", x, x + 1, x - 2, x - 5);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x + 1;
		moves[x - 1].seq[hops].p2 = x - 2;
		moves[x - 1].seq[hops].end = x - 5;
		moves[x - 1].count++;
		hops++;
	}

	//8. 1 right + 2 down's
	if (is_a_valid_move(x, x + 1) && is_a_valid_move(x + 1, x + 1 + 3) && is_a_valid_move(x + 1 + 3, x + 1 + 6)) {
		//printf("8. move %d -> %d -> %d -> %d ok\n", x, x + 1, x + 4, x + 7);
		moves[x - 1].seq[hops].start = x;
		moves[x - 1].seq[hops].p1 = x + 1;
		moves[x - 1].seq[hops].p2 = x + 4;
		moves[x - 1].seq[hops].end = x + 7;
		moves[x - 1].count++;
		hops++;
	}

	//9. 2 up's + 1 left
		if (is_a_valid_move(x, x - 3) && is_a_valid_move(x - 3, x - 6) && is_a_valid_move(x - 6, x - 5)) {
			//printf("9. move %d -> %d -> %d -> %d ok\n", x, x - 3, x - 6, x - 5);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x - 3;
			moves[x - 1].seq[hops].p2 = x - 6;
			moves[x - 1].seq[hops].end = x - 5;
			moves[x - 1].count++;
			hops++;
		}

		//10. 2 up's + 1 right
		if (is_a_valid_move(x, x - 3) && is_a_valid_move(x - 3, x - 6) && is_a_valid_move(x - 6, x - 7)) {
			//printf("10. move %d -> %d -> %d -> %d ok\n", x, x - 3, x - 6, x - 7);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x - 3;
			moves[x - 1].seq[hops].p2 = x - 6;
			moves[x - 1].seq[hops].end = x - 7;
			moves[x - 1].count++;
			hops++; // up
		}

		//11. 2 down's + 1 left
		if (is_a_valid_move(x, x + 3) && is_a_valid_move(x + 3, x + 6) && is_a_valid_move(x + 6, x + 5)) {
			//printf("11. move %d -> %d -> %d -> %d ok\n", x, x + 3, x + 6, x + 5);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x + 3;
			moves[x - 1].seq[hops].p2 = x + 6;
			moves[x - 1].seq[hops].end = x + 5;
			moves[x - 1].count++;
			hops++;
		}

		//12. 2 down's + 1 right
		if (is_a_valid_move(x, x + 3) && is_a_valid_move(x + 3, x + 6) && is_a_valid_move(x + 6, x + 7)) {
			//printf("12. move %d -> %d -> %d -> %d ok\n", x, x + 3, x + 6, x + 7);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x + 3;
			moves[x - 1].seq[hops].p2 = x + 6;
			moves[x - 1].seq[hops].end = x + 7;
			moves[x - 1].count++;
			hops++;
		}

		//13. 2 left's + 1 up
		if (is_a_valid_move(x, x - 1) && is_a_valid_move(x - 1, x - 2) && is_a_valid_move(x - 2, x - 5)) {
			//printf("13. move %d -> %d -> %d -> %d ok\n", x, x - 1, x - 2, x - 5);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x - 1;
			moves[x - 1].seq[hops].p2 = x - 2;
			moves[x - 1].seq[hops].end = x - 5;
			moves[x - 1].count++;
			hops++;
		}

		//14. 2 left's + 1 down
		if (is_a_valid_move(x, x - 1) && is_a_valid_move(x - 1 , x - 2) && is_a_valid_move(x - 2, x + 1)) {
			//printf("14. move %d -> %d -> %d -> %d ok\n", x, x - 1, x - 2, x + 1);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x - 1;
			moves[x - 1].seq[hops].p2 = x - 2;
			moves[x - 1].seq[hops].end = x + 1;
			moves[x - 1].count++;
			hops++;
		}

		//15. 2 right's + 1 up
		if (is_a_valid_move(x, x + 1) && is_a_valid_move(x + 1, x + 1 - 3) && is_a_valid_move(x + 1 - 3, x + 1 - 6)) {
			//printf("15. move %d -> %d -> %d -> %d ok\n", x, x + 1, x - 2, x - 5);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x + 1;
			moves[x - 1].seq[hops].p2 = x - 2;
			moves[x - 1].seq[hops].end = x - 5;
			moves[x - 1].count++;
			hops++;
		}

		//16. 2 right's + 1 down
		if (is_a_valid_move(x, x + 1) && is_a_valid_move(x + 1, x + 2) && is_a_valid_move(x + 2, x + 5)) {
			//printf("16. move %d -> %d -> %d -> %d ok\n", x, x + 1, x + 2, x + 5);
			moves[x - 1].seq[hops].start = x;
			moves[x - 1].seq[hops].p1 = x + 1;
			moves[x - 1].seq[hops].p2 = x + 2;
			moves[x - 1].seq[hops].end = x + 5;
			moves[x - 1].count++;
			hops++;
		}
	return hops;
}

void setup() {
	moves = (ValidMoves *) malloc (M * N * sizeof(ValidMoves));

		for (int i = 0; i < M * N; i++) {
			moves[i].key = (i + 1);
			moves[i].count = 0;
			moves[i].seq = (Sequence *)malloc(5 * sizeof(Sequence));
		}

		int pad[M][N] = { {1, 2, 3},
						  {4, 5, 6},
						  {7,8, 9},
						  {10, 11, 12} };
		for (int i = 0; i < M; i++)
			for (int j = 0; j < N; j++)
				solver(pad, pad[i][j]);

		// print ValidMoves
		int total_moves = 0;
		for (int i = 0; i < M * N; i++) {
			printf("x = %d: count = %d\n", (i + 1), moves[i].count);
				for (int j = 0; j < moves[i].count; j++) {
					total_moves++;
					printf("\t%d, %d, %d, %d\n", moves[i].seq[j].start, moves[i].seq[j].p1, moves[i].seq[j].p2, moves[i].seq[j].end);
				}
			//free(moves[i].seq);
		}
		//free(moves);
		printf("total # of valid moves: %d\n", total_moves);
}

void clear() {
	for (int i = 0; i < M * N; i++) {
				free(moves[i].seq);
			}
			free(moves);
}
void dial() {
	int start = 6, end = 0;
	int max_hops = 100;
	int count = 0;
	srand((unsigned) time(NULL));
	while (count < max_hops) {
		int moves_count = moves[start - 1].count;
		int idx = rand() % moves_count;
		int p1 = moves[start - 1].seq[idx].p1;
		int p2 = moves[start - 1].seq[idx].p2;
		end = moves[start - 1].seq[idx].end;
		printf("start = %d, end = %d: [%d -> %d -> %d -> %d]\n", get_digit(start), get_digit(end), get_digit(start), get_digit(p1), get_digit(p2), get_digit(end));
		start = end;
		count++;
	}

	printf("total numbers dialed: %d\n", count);
}
int main()
{
	setup();
	dial();
	clear();
}

