/*
 * dijkstra_matrix.c
 * Set INFINITY to INT_MAX will not work
 */
#include <stdio.h>
#include <stdbool.h>
#define INFINITY 1000000
#define MAX 10

typedef struct path {
	int distance;
	int prev_node;
	bool visited;
} Path;
Path path[MAX];

void dijkstra(const int G[MAX][MAX], int n, int origin);

void test() {
	int n = 9, origin = 0;
	int G[MAX][MAX] = { [0 ... MAX - 1] = { [0 ... MAX - 1] = INFINITY } };
	//un-directed graph
	G[0][1] = G[1][0] = 4;
	G[0][7] = G[7][0] = 8;
	G[1][2] = G[2][1] = 8;
	G[1][7] = G[7][1] = 11;

	G[2][3] = G[3][2] = 7;
	G[2][8] = G[8][2] = 2;
	G[2][5] = G[5][2] = 4;
	G[3][4] = G[4][3] = 9;

	G[3][5] = G[5][3] = 14;
	G[4][5] = G[5][4] = 10;
	G[5][6] = G[6][5] = 2;
	G[6][7] = G[7][6] = 1;

	G[6][8] = G[8][6] = 6;
	G[7][8] = G[8][7] = 7;

	dijkstra(G, n, origin);

	// since the graph is undirected, the first node to last node represents the optimal path for all nodes inbetween.
	// print distances for all paths
	int i, j;
	for (i = 1; i < n; i++) {
		printf("\nDistance of node from origin %d to %d is %d : path = %d", origin, i, path[i].distance, i);

		j = i;
		do {
			j = path[j].prev_node; // j is the index of the prev node so prev_node is assigned to j each time
			printf(" <- %d ", j);
		} while (j != origin);
	}
	putchar('\n');
}

int main() {
	test();
}

void dijkstra(const int cost[MAX][MAX], int n, int origin) {

	// (1) declare i, which will be used throughout the function
	int i;

	// (2) initialize path array
	for (i = 0; i < n; i++) {
		path[i].distance = cost[origin][i];
		path[i].prev_node = origin;
		path[i].visited = false;
	}

	// (3) initialize path for the origin node
	path[origin].distance = 0;
	path[origin].visited = true;

	// (4) set up the count variable, min_distance and prev_node
	int count = 1, min_distance, prev_node;

	// (5) one while-loop with two embedded parallel for-loops
	while (count < n) {
		printf("count = %d\n", count);
		min_distance = INFINITY;

		//prev_node gives the node at minimum distance
		for (i = 0; i < n; i++)
			if (!path[i].visited && path[i].distance < min_distance) {
				min_distance = path[i].distance;
				prev_node = i;
				printf("during 1st for-loop: dest = %d, min_distance= %d\n",
						prev_node, min_distance);
			}

		//check if a better path exists through prev_node
		//path[prev_node].visited = true; // do not set here. Not visited until next for-loop
		for (i = 0; i < n; i++)
			if (!path[i].visited && path[i].distance > (min_distance + cost[prev_node][i])) {
				path[i].distance = min_distance + cost[prev_node][i];
				path[i].prev_node = prev_node;
				printf("during 2nd for-loop: i = %d, path[i].distance = %d: %d-> %d ->%d\n",
						i, path[i].distance, origin, prev_node, i);
			}

		printf("<<mark node %d visited>>\n\n", prev_node);
		path[prev_node].visited = true; // set visited
		count++;
	}
}
